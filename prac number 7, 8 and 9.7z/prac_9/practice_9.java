import java.util.Scanner;

public class practice_9 {

    public static String getInputLine() {
        Scanner scan = new Scanner(System.in);
        String text;

        while (true) {
            System.out.println("Введіть строку (мінімум 2 слова, кожне не менше 3 символів):");
            text = scan.nextLine().trim();

            String[] words = text.split("\\s+");

            if (words.length < 2) {
                System.out.println("Помилка: потрібно мінімум 2 слова.");
                continue;
            }

            boolean valid = true;
            for (String w : words) {
                if (w.length() < 3) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                return text;
            } else {
                System.out.println("Помилка: кожне слово має містити мінімум 3 символи.");
            }
        }
    }

    public static String reverseWhole(String data) {
        StringBuilder sb = new StringBuilder(data);
        return sb.reverse().toString();
    }

    public static String reverseSeparate(String data) {
        String[] list = data.split("\\s+");
        StringBuilder result = new StringBuilder();

        for (String word : list) {
            result.append(new StringBuilder(word).reverse()).append(" ");
        }

        return result.toString().trim();
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String sourceText = getInputLine();

        System.out.println("Оберіть дію:");
        System.out.println("1 - Перевернути всю строку");
        System.out.println("2 - Перевернути кожне слово окремо");

        int choice = scan.nextInt();

        if (choice == 1) {
            System.out.println("Результат:");
            System.out.println(reverseWhole(sourceText));
        } else if (choice == 2) {
            System.out.println("Результат:");
            System.out.println(reverseSeparate(sourceText));
        } else {
            System.out.println("Невірний вибір.");
        }
    }
}
