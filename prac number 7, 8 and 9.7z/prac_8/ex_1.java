import java.util.Scanner;

public class ex_1 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Введіть рядок: ");
        String input = sc.nextLine();

        String clean = input.toLowerCase().replace(" ", "");
        String reversed = "";

        for (int i = clean.length() - 1; i >= 0; i--) {
            reversed += clean.charAt(i);
        }

        if (clean.equals(reversed)) {
            System.out.println("Це паліндром.");
        } else {
            System.out.println("Це не паліндром.");
        }
    }
}
