import java.util.Scanner;

public class ex_3 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Введіть рядок: ");
        String input = sc.nextLine().trim() + " ";

        String current = "";
        String shortest = "";
        String longest = "";

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);

            if (ch != ' ') {
                current += ch;
            } else {
                if (!current.equals("")) {

                    if (shortest.equals("") || current.length() < shortest.length()) {
                        shortest = current;
                    }

                    if (current.length() > longest.length()) {
                        longest = current;
                    }

                    current = "";
                }
            }
        }

        System.out.println("Найменше слово: " + shortest + " (" + shortest.length() + " символи)");
        System.out.println("Найдовше слово: " + longest + " (" + longest.length() + " символи)");
    }
}
