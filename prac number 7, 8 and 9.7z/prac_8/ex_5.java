import java.util.Scanner;

public class ex_5 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Введіть рядок: ");
        String line = sc.nextLine();

        String bad1 = "погане";
        String bad2 = "слово";

        String mask1 = "***";
        String mask2 = "[цензура]";

        String result = line;

        result = result.replace(bad1, mask1);
        result = result.replace(bad2, mask2);

        System.out.println("Результат: " + result);
    }
}
