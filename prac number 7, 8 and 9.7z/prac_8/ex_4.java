import java.util.Scanner;

public class ex_4 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Введіть рядок: ");
        String input = sc.nextLine();

        String result = "";
        boolean toUpper = false;

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);

            if (ch == '-' || ch == '_') {
                toUpper = true;
            } else {
                if (toUpper) {
                    result += Character.toUpperCase(ch);
                    toUpper = false;
                } else {
                    result += Character.toLowerCase(ch);
                }
            }
        }

        System.out.println("CamelCase: " + result);
    }
}
