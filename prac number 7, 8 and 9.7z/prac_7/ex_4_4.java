import java.util.Scanner;

public class ex_4_4 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Введите размер матрицы (n): ");
        int n = sc.nextInt();

        double[][] mat = new double[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = Math.random() * 100;
            }
        }

        System.out.println("\nИсходная матрица:");
        displayMatrix(mat);

        System.out.print("\nВведите номер строки для минора (от 1 до " + n + "): ");
        int delRow = sc.nextInt() - 1;

        System.out.print("Введите номер столбца для минора (от 1 до " + n + "): ");
        int delCol = sc.nextInt() - 1;

        double[][] minorMat = getMinor(mat, delRow, delCol);

        System.out.println("\nМинор матрицы (без строки " + (delRow + 1) +
                " и столбца " + (delCol + 1) + "):");
        displayMatrix(minorMat);

        sc.close();
    }

    public static double[][] getMinor(double[][] arr, int rowToRemove, int colToRemove) {
        int size = arr.length;
        double[][] result = new double[size - 1][size - 1];

        int rIndex = 0;
        for (int i = 0; i < size; i++) {
            if (i == rowToRemove) continue;
            int cIndex = 0;
            for (int j = 0; j < size; j++) {
                if (j == colToRemove) continue;
                result[rIndex][cIndex] = arr[i][j];
                cIndex++;
            }
            rIndex++;
        }
        return result;
    }

    public static void displayMatrix(double[][] arr) {
        for (double[] row : arr) {
            for (double val : row) {
                System.out.printf("%8.2f", val);
            }
            System.out.println();
        }
    }
}
