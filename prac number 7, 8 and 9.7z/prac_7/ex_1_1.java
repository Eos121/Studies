import java.util.Scanner;

public class ex_1_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Введите количество строк (n >= 1): ");
        int n = sc.nextInt();
        if (n < 1) {
            System.out.println("n должно быть >= 1");
            return;
        }

        int mid = (n + 1) / 2;

        int[][] pyramid = new int[n][];
        int num = 1;
        for (int i = 0; i < n; i++) {
            int len = (i < mid) ? (i + 1) : (n - i);
            pyramid[i] = new int[len];
            for (int j = 0; j < len; j++) {
                pyramid[i][j] = num++;
            }
        }

        System.out.println("\nОбычный порядок (пирамидой):");
        showPyramid(pyramid, mid);

        System.out.println("\nОбратный порядок (пирамидой):");
        int[][] rev = reverseRows(pyramid);
        showPyramid(rev, mid);

        sc.close();
    }

    private static void showPyramid(int[][] arr, int maxLen) {
        for (int i = 0; i < arr.length; i++) {
            int len = arr[i].length;
            int spaces = (maxLen - len) * 2;
            for (int s = 0; s < spaces; s++) System.out.print(" ");
            for (int j = 0; j < len; j++) {
                System.out.print(arr[i][j]);
                if (j != len - 1) System.out.print(" ");
            }
            System.out.println();
        }
    }

    private static int[][] reverseRows(int[][] src) {
        int n = src.length;
        int[][] res = new int[n][];
        for (int i = 0; i < n; i++) {
            res[i] = src[n - 1 - i];
        }
        return res;
    }
}
